package app.kodigo.gj;

import android.view.Surface;

public class JNI
{
	public static native void nativeOnCreate();
    public static native void nativeOnResume();
    public static native void nativeOnFocusChanged(boolean focus);
    public static native void nativeOnPause();
    public static native void nativeOnDestroy();
    public static native void nativeSurfaceChanged(Surface surface);
    public static native void nativeSurfaceDestroyed(Surface surface);
    public static native void nativeOnTouchEvent(int state, int index, float x, float y, float rawX, float rawY);
    public static native void nativeOnLayout(int viewLeft, int viewRight, int viewTop, int viewBottom, int usableLeft, int usableRight, int usableTop, int usableBottom);

}
