package  app.kodigo.gj.pixelized;

import android.app.Application;
import app.kodigo.gj.JNI;

class MainApp extends Application
{
	@Override
	public void onCreate() {
		super.onCreate();
        JNI.nativeOnCreate();
	}

	@Override
	public void onTerminate() {
		super.onTerminate();
        JNI.nativeOnDestroy();
	}
}
